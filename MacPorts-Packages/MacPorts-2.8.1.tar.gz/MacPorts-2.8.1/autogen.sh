#!/bin/sh

autoreconf --force -Wall -Werror
