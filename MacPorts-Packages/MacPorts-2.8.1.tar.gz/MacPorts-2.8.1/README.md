# macports-base

This repository contains the source code for the MacPorts command-line client.

Official documentation: <https://guide.macports.org/>
